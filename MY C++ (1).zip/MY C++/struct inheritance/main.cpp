#include <iostream>
using namespace std;

struct shape
{
    string shape_kind;
    int length, width, area, perimeter;
    void input(), compute(), display();

};
struct rectangle:public shape
{
public:

         void input()
       {
        cout<<"Enter the length:";
        cin>>length;
        cout<<"Enter the width:";
        cin>>width;
       }


       void compute()
       {
        area = length * width;
        perimeter = (length + width) * 2;
       }
       void display()
       {
        cout<<"The area of the rectangle is :"<<area;
        cout<<"The primeter of the rectangle is :"<<perimeter;
        }

};
int main()
{
   rectangle rect;
   rect.input();
   rect.compute();
   rect.display();

    return 0;
}
