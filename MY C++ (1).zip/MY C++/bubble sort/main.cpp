#include<iostream>
using namespace std;

int main()
{
    int arr[5]= {4,5,1,2,3};
    int i,j, temp;

    for(i=0; i<5; i++)
    {
        for(j=i+1; j<5; j++)
        {
            if (arr[i] > arr[j])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        cout<<arr[i]<<endl;
    }
    return 0;

}
