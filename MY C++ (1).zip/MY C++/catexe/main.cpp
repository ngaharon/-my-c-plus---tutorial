#include <iostream>

using namespace std;

public class Person {
    private String name;
    private int age;
    private int number;

};

