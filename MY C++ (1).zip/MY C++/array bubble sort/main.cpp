#include <iostream>

using namespace std;

int main()
{
    int numb[7] = {2,3,6,7,4,8,5};

   for (int i=0; i<=6; i++)
    {
        for (int j=i+1; j<=5; j++)
        {
            if (numb[i] > numb[j])
            {
                int temp;
                temp = numb[i];
                numb[i] = numb[j];
                numb[j] = temp;
            }
            cout<<numb[i]<<endl;
        }
    }
    return 0;
}
