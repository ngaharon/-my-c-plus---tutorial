#include<iostream>
using namespace std;

class Person
{ protected:
    string gender;


};


class men: public Person
{
    char name[50];
    int age;
    int phone;

    public:
        void get_details();
        void display();
};

void men::get_details()
{
    cout << "Gender : Male";
    cout<<"\nEnter the Name:";
    cin>>name;
    cout<<"Enter the age:";
    cin>>age;
    cout<<"Enter phone:";
    cin>>phone;
}


class female: public Person
{
    char name[50];
    int age;
    int phone;

    public:
        void get_details();
        void display();
};

void female::get_details()
{
    cout<<"\nGender : Female"<<endl;
    cout<<"\nEnter the Name:";
    cin>>name;
    cout<<"\nEnter the age:";
    cin>>age;
    cout<<"\nEnter phone:";
    cin>>phone;
}
void men::display()
{
    cout<<"\t\tName is :"<<name;
    cout<<"\n\t\tAge is :"<<age;
    cout<<"\n\t\tphone is :"<<phone;
}

void female::display()
{
    cout<<"\t\tName is :"<<name<<endl;
    cout<<"\t\tAge is :"<<age<<endl;
    cout<<"\t\tphone is :"<<phone<<endl;
}

int main()
{
    men m;

    female f;

    m.get_details();
    m.display();
    f.get_details();
    f.display();

    return 0;
}
