#include<iostream>
using namespace std;

int product(int i,int j);
int product(int i, int j, int k);
int product(int i, int j, int k, int l);
int main()
{
int i,j,k,l, answer;
cout<<"Enter the value of i,j,k,l:\n";
cin>>i;
cin>>j;
cin>>k;
cin>>l;
cout<<"\nproduct(i,j):"<<i*j;
cout<<"\nproduct(i,j,k):"<<i*j*k; //will do leter
cout<<"\nproduct(i,j,k,l):"<<i*j*k*l;
return 0;
}
int product(int a, int b)
{
double multiply;
multiply = a * b;
return multiply;
}
int product(int a, int b, int c)
{
int multiply;
multiply = a * b * c;
return multiply;
}
int product(int a, int b, int c, int d)
{
int multiply;
multiply = a * b * c * d;
return multiply;
}

