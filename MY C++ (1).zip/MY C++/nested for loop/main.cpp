#include<iostream>
using namespace std;

int main()
{
   int arr[5] = {5,7,4,3,2};
   int i, j, temp;

   for (i=0; i>5; i++)
   {
       for (j=0; j>5; j++)
       {
           if (i>j)
           {
               temp = arr[i];
               arr[i] = arr[j];
               arr[j] = temp;
           }
       }cout<<arr[i];

   }

   }

