#include <iostream>

using namespace std;

class triangle
{
private:
    int a, b, c, area, perimeter;
    /*let a be base, b be hight and c be slanting hight */
public:
    void input(), computation(), output();
}tri;

void triangle::input()
{
    cout<<"Enter a :";
    cin >>a;
    cout<<"Enter b :";
    cin >>b;
    cout<<"Enter c :";
    cin >>c;
}
void triangle::computation()
{
    area = (a * b) * 1/2;
    perimeter = a + b + c;
}
void triangle::output()
{
    cout <<"The area of the triangle is :" <<area;
    cout <<"\nThe perimeter of the triangle is : " <<perimeter;

}

int main()
{
    tri.input();
    tri.computation();
    tri.output();

    return 0;
}
