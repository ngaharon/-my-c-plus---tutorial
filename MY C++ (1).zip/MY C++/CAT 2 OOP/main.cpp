#include <iostream>
using namespace std;

class triangle {
  private:
    int base, height;

  public:
    triangle(int bse, int hgt) {
      base = bse;
      height = hgt;
    }

    int compute_area() {
      return (base * height) * 0.5;
    }
};

int main() {
  triangle tri1(20, 10);
  triangle tri2(16, 13);

  cout << "Area of triangle 1: " << tri1.compute_area() << endl;
  cout << "Area of triangle 2: " << tri2.compute_area();

  return 0;
}
