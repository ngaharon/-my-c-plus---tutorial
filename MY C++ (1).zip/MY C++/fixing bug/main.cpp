#include <iostream>

using namespace std;

int main()
{
    /*Enter this program and compile it. Why does it fail? How can you fix it?
#include <iostream>
main( )
{
 cout << Are you are a C++ Programmer?"
{
5. Fix the bugs in question 4 and recompile, link, and run it*/


 cout << "Are you are a C++ Programmer?";

/*This program failed because syntax error since their was no opening quotation mark,
theirs was also not semi_colons*/

        return 0;
}
