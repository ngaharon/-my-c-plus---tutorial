#include <iostream>

using namespace std;

int main()
{
    int a, b, c;
    cout<<"Enter a :"<<endl;
    cin>>a;
    cout<<"Enter b :"<<endl;
    cin>>b;
    cout<<"Enter c :"<<endl;
    cin>>c;

    if (a > c)
    {
       cout<<"A is the largest number";
    }
    else if (a > b)
    {
     cout<<"A is largest number of all";
    }
    else if (b > a)
    {
     cout<<"B is largest number of all";
    }
    else if (b > c)
    {
     cout<<"B is largest number of all";
    }
    else if (c > a)
    {
     cout<<"C is largest number of all";
    }
    else
    {
     cout<<"C is largest number of all";
    }

    return 0;
}
