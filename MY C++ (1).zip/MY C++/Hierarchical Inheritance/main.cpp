#include <iostream>

using namespace std;
class shape
{
protected:
    int length, width, radius, side, pie = 3.14,area, perimeter, circumference;
public:
    void input(), compute(), output();
};

class rectangle: public shape
{
public:
    void input()
    {
        cout<<"Enter the length:";
        cin>>length;
        cout<<"Enter width:";
        cin>>width;
    }
    void compute()
    {
        area = length * width;
        perimeter = 2 *( length * width);
    }
    void output()
    {
        cout <<"The area of rectangle is:"<<area<<endl;
        cout<<"The perimeter of rectangle is:"<<perimeter;
        cout<<"\n============================================================================================";
    }
};

class circle: public shape
{
public:
    void input()
    {
        cout<<"\nEnter the radius:";
        cin>>length;

    }
    void compute()
    {

        area = radius * radius * pie;
        circumference = pie * 2 * radius;
    }
    void output()
    {
        cout <<"The area of circle is:"<<area<<endl;
        cout<<"The circumference of circle is:"<<circumference;
        cout<<"\n============================================================================================";
    }
};
class square: public shape
{
public:
    void input()
    {
        cout<<"\nEnter the side:";
        cin>>side;

    }
    void compute()
    {
        area = side * side;
        perimeter = side * 4;
    }
    void output()
    {
        cout <<"The area of square is:"<<area<<endl;
        cout<<"The perimeter of square is:"<<perimeter;
        cout<<"\n============================================================================================";
    }
};


int main()
{
    rectangle rect;
    circle circ;
    square sqrt;
    rect.input();
    rect.compute();
    rect.output();
    circ.input();
    circ.compute();
    circ.output();
    sqrt.input();
    sqrt.compute();
    sqrt.output();

    return 0;
};
