#include <iostream>

using namespace std;

int main()
{
   /* char strg[]= "you've entered a number greater than 7 or less than 0 ";
    int day;
    cout <<"Enter the number of the day :";
    cin>>day;
    switch (day) {
case 1:
    cout<<"Monday";
    break;
case 2:
    cout<<"Tuesday";
    break;
case 3:
    cout<<"Wednesday";
    break;
case 4:
    cout<<"Thursday";
    break;
case 5:
    cout<<"Friday";
    break;
case 6:
    cout<<"Saturday ";
    break;
case 7:
    cout<<"sunday";
    break;
    }

     if (day <= 0 || day >=8)
     {
         cerr<<"Error :"<<strg;
         //cerr( c error) object is attached to standard error device
     }
     */
   /* int x = 9999;
     while (x > 1)
     {
         cout<<x<<endl;
         x--;
     }

    int x = 9999;
    do {
        cout<<x<<endl;
        x--;
        if (x == 9990)
        {
            break;
        }

    }
    while (x > 1000);
        */
    int i, j;
    int x[3][2] = {{1,2,3},{6,7,8},{4'5'9}};
    for (int i = 0; i < 3; i++)
    {
        for (j=0; j<4; j++)
    }

    cout <<x[i][j] <<endl;


    return 0;
}
