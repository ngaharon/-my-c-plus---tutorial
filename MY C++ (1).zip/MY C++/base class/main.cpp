#include <iostream>

using namespace std;

class shape
{
protected:
    int length, width, radius, area, perimeter, circumference;
public:
    void input(), compute(), output();
};

class rectangle: public shape
{
public:
    void input()
    {
        cout<<"Enter the length of the rectangle:";
        cin>>length;
        cout<<"Enter the width of the rectangle:";
        cin>>width;
    }
    void compute()
    {
        area = length * width;
        perimeter = 2 * (length + width);
    }
    void output()
    {
        cout<<"The area of the rectangle is :"<<area;
        cout<<"\nThe perimeter of the rectangle is :"<<perimeter;

    }
    };

int main()
{
    rectangle rect;
    rect.input();
    rect.compute();
    rect.output();

    return 0;
}

