#include <iostream>

using namespace std;

int main()
{
   /* class food{
    public: string food_name; int item_number; int price;
    };
    class drinks {string type_of_drinks; int drinks_number; int drinks_price;
    };*/
    cout << "*********WELCOME TO ZETECH RESTURANT***********" << endl;
    cout << "**************TODAYS SPECIALS***********" << endl;

    cout << "ITEM NUMBER        NAME            PRICE UNIT " << endl;
    cout << "1.     Fish served with rice         500" << endl;
    cout << "2.     Beef served with ugali        150 " << endl;
    cout << "3.     chicken served with chapati   300" << endl;

    cout << " ********************DRINKS**************" << endl;
    cout << "1.     Fruit juice                  100" << endl;
    cout << "2.    soda                          50" << endl;
    cout << "3.    lemon water                   40" << endl;
    cout << "4.    Tea                           30" << endl;
    cout << "================================================" << endl;
    cout << "                      Total price : 1,170 ksh" << endl;
    return 0;
}
