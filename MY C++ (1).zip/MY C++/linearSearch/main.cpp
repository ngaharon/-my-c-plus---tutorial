#include <iostream>

using namespace std;

int main()
{
    int arr[5] = {3,7,9,20,26};
    int temp = -1, numb;
    cout<<"Enter number to search :";
    cin>>numb;
    for (int i=0; i<5; i++)
    {
        if (numb == arr[i])
        {
            temp = arr[i];

            if (temp > 0)
        {
            cout<<"The number search is found at position "<<i<<endl;
            break;
        }

        else
        {
            cout<<"The number searched is not found";
            //break;
        }
        }

    return 0;
}
