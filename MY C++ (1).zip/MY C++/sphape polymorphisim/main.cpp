#include<iostream>
using namespace std;

double area(int length , int width);
double area(int radius);
double area (int length, int width);

int main()
{
    double length, width, radius, answer;

    cout<<"Enter the length and width of the rectangle">>lenghth>>width;

}

double area(double length, double width)
{
double total;
total = length * width;
return total;
}
double area(double radius)
{
double total;[]
toal = 2 * 3.14 * radius ;
return total;
}
double area(double length, double width)
{
double total;
sum =( length * width ) * 1/2;
return total;
}
