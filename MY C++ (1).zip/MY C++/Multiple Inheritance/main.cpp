#include <iostream>

using namespace std;

class shape
{
protected:
    int length, width;
    float area;
public:
    void input(), compute(), output();
};

class rectangle: public shape
{
public:
    void input(), compute(), output();
};

class rectangle2 : public shape, public rectangle
{
    public:
    void input(), compute(), output();

};
class rectangle2 ::inpute()
{
    cout<<"Enter the length and width"<<endl;
    cin>>length;
    cin>>width;
};
class rectangle2::compute()
{
    area = length * width;
};
class rectangle2::output()
{
    cout<<"The area of rectangle 2 is :"<<area;
};

int main()
{
    rectangle2 rect;
    rect.input();
    rect.compute();
    rect.output();

    return 0;
}


