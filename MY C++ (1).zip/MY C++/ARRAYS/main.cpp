#include <iostream>

using namespace std;

int main()
{
   int arr[5] = {2,4,6,8,3};
   int temp;
   for (int i = 0; i<=4; i++)
   {
       for ( int j =i+1; j<=5; j++)
       {
           if (arr[i] < arr[j])
           {
               temp =arr[i];
               arr[i] = arr[j];
               arr[j] = temp;
           }
       }       cout<<arr[i] <<endl;
   }
    return 0;
}
