#include <iostream>

using namespace std;

int main()
{
    int n1, n2, n3;
    float product;
    cout << "A program to compute 3 numbers!\n" << endl;
    cout <<"Enter the first number:";
    cin>>n1;
    cout<<"Enter the 2nd numbers:";
    cin>>n2;
    cout<<"Enter the 3rd numbers:";
    cin>>n3;

    cout<<"product is : "<<(n1 * n2 * n3);

    return 0;
}
