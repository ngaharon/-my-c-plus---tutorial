#include <iostream>

using namespace std;

int main()
{
    /*A C++ program is required that calculates the area and circumference of a circle
with a diameter of 14cm.
*/
    float d = 14, pi = 3.14;
    cout <<"The circumference of the circle is : "<<(pi * d);
    return 0;
}
