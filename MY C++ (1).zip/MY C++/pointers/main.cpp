#include <iostream>

using namespace std;

int main()
{
   int x = 27;
   int *ptr;
    ptr = &x;

    cout<<"The value of x is :"<<x<<endl;
    cout<<"The value of *ptr :"<<ptr<<endl;
    if (x == *ptr) // *ptr also the value of x which is 5 because it points to x
    }
    else
    {
        cout<<"*ptr doesn't work like that";
    }
    return 0;
}
