#include <iostream>
#include<fstream>
using namespace std;


int main()
{
    fstream example1;
    example1.open("example", ios::out);
    if (!example1)
    {
        cout<<"File not found";
    }
    else
        {
        cout<<"file created successfully ";

        }


    return 0;
}
