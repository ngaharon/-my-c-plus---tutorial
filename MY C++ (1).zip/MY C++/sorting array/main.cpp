#include <iostream>

using namespace std;

int main()
{
    int arr[5]={6,7,8,5,4};
    int i, j;
    cout<<"original array :";
    for (i=0; i<5; i++)
    {
    cout<<arr[i];
    }
    cout<<endl;
    for (i=0; i<=5; i++)
    {
        for (j=i+1; j<5; j++)
        {
          if (arr[i] > arr[j])
        {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
        }
    }
        cout<<"The sorted array is :";

    for (i=0; i<5; i++)
    {
        cout<<arr[i];
    }

    return 0;
}
