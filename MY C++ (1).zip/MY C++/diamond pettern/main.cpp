#include <iostream>

int main() {
  int i, j, k, l,rows;
  std::cout<<"Enter the number of rows:";
  std::cin>>rows;
  for (i=1; i<=rows; i++)
    {
      for(j=1; j<=i; j++)
      {
    std::cout<<"*";
      }
      std::cout<<"\n";
    }
  for (k=rows; k<=1; k--)
  {
      for (l=1; l<=k; l++)
      {
          std::cout<<"*";
      }
      std::cout<<"\n";
  }
    return 0;
}
