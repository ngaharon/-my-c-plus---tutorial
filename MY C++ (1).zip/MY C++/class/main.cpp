#include <iostream>

using namespace std;

class shape{
protected:
    int length, width, hieght, radius, side, area;
public:
    void get_data(), compute_data(), display_data();
    };

class rectangle : public shape
 {
public:
        void get_data()
        {
            cout<<"Enter the length and the width :";
            cin>>length;
            cin>>width;
        }
        void compute_data()
        {
            area = length * width;
        }
        void display_data()
        {
            cout<<"The area of rectangle : ";
            cout<<area;
        }
    };
int main()
{
    rectangle rect;
    rect.get_data();
    rect.compute_data();
    rect.display_data();
    return 0;
}
