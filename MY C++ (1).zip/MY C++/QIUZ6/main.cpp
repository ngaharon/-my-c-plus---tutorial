#include <iostream>

using namespace std;

int main()
{
   /* Calculate value of each of the following C++ statements (show you�re working).
b = 12 + 4 � 7 * 9 % 6 + 12/
c = 13 � (8%5) -9%7 � 3 + 6 * 2
*/


    cout<<" Result for b is :"<<12 + 4 - 7 * 9 % 6 + 12 ;
    cout<<"The result for c is :"<<(13 � (8%5) -9%7 � 3 + 6 * 2) ;


    return 0;
}
