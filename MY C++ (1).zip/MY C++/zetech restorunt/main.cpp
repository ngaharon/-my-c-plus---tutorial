#include <iostream>

using namespace std;

int main()
{
    int  Fish_rice= 500, Beef_Ugali=150, Chicken_chapati=300;
    cout<<"***************WELCOME TO ZETECH RESTURANT**********";
    cout<<"\n\t********TODAYS SPECIAL**********";
    cout<<"ITEM NUMBER       NAME                                 UNIT PRICE";

}
