#include <iostream>

using namespace std;

class biz
{
private:
    int buying_price, trans_cost, selling_price, profit, loss;

public:
    void input(), calculate(), output();

}p;

void biz::input()
{
    cout<<"Enter the buying price of the item:";
    cin>>buying_price;
    cout<<"\nEnter the transport cost:";
    cin>>trans_cost;
    cout<<"\nEnter the selling price of the item:";
    cin>>selling_price;
}
void biz::calculate()
{
    profit = (buying_price + trans_cost) - selling_price;
    loss = selling_price - (buying_price + trans_cost);

}
void biz::output()
{
    if (selling_price > buying_price)
    {
    cout<< "The profit of the item is : "<<profit;
    }
    else {
    cout<<"The loss made form the item is: "<<loss;
    }
}
int main()
{
    p.input();
    p.calculate();
    p.output();

    return 0;
}
