#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    int n1, n2, sum;
    float avrg;
    cout << "A program to compute 3 numbers!\n" << endl;
    cout <<"Enter the first number:";
    cin>>n1;
    /* we can cascade the input eg. cin>>n1>>n2; instdeade of cin>>n1; and cin>>n2; */
    cout<<"Enter the 2nd numbers:";
    cin>>n2;

    cout<<"sum : "<<(n1 + n2);
    cout<<"\n avarge is : "<<((n1 + n2 )/2);

    // <<endl can be used instade of \n

    return 0;
}
