#include <iostream>
#include <cmath>
#define pi 3.14
using namespace std;

class my_circle {
private:
    int raduis, area, circum;

public:
    void input(), computation(), output();

}circ;


void my_circle::input()
    {
        cout<< "\nEnter the raduis of the circle:";
        cin>>raduis;
    }
void my_circle::computation()
{

    area = pi * (raduis * raduis);
    circum = 2 * (pi * raduis);
}

void my_circle::output()
{
    cout<< "The area of the circle is :" <<area;
    cout<<"\nThe circumference of the circle is :"<<circum;
}

int main()
{
    my_circle circ;
    circ.input();
    circ.computation();
    circ.output();

    return 0;
}
