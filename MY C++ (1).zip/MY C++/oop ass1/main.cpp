#include <iostream>

using namespace std;

int main()
{
    int fish_rice =500, beef_ugali = 150, chicken_chapati = 300;
    int fruit_juice =100, soda = 50, lemon_water=40, tea = 30, total;
    cout<<"*******************    WELCOME TO ZETECH RESTURANT     *******************";
    cout<<"\n\t\t********TODAYS SPECIAL*********";
    cout<<"\n\ITEM NUMBER\tNAME\t\tUNIT PRICE";
    cout<<"\n\t1.Fish served with rice \t"<<fish_rice;
    cout<<"\n\t2.Beef served with Ugali \t"<<beef_ugali;
    cout<<"\n\t3.Chicken served with chapati \t"<<chicken_chapati;
    cout<<"\n\t\t*********DRINKS*********";
    cout<<"\n\t1.Fruit Juice\t" <<fruit_juice;
    cout<<"\n\t2.Soda\t\t" <<soda;
    cout<<"\n\t3.Lemon water\t"<<lemon_water;
    cout<<"\n\t4.Tea\t\t"<<tea;
    total = fish_rice + beef_ugali + chicken_chapati + fruit_juice + soda + lemon_water + tea;
cout<<"\n==========================================";
cout<<"\n\tTotal bill is :"<<total;
}
