#include<iostream>
using namespace std;
main( )
{
    int numb[4][2] = {
        { 1, 2 },
        { 3, 4 },
        { 5, 6 },
        { 7, 8 }
        } ;

    int i,j;

    cout<<"The array number are:\n";
    for(i=0;i<4;i++)
    {
        for(j=0;j<2;j++)
        {
        cout<<"\t"<<numb[i][j];

        }
        cout<<endl;
    }
}
