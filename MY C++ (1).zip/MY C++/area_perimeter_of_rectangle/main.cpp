#include <iostream>

using namespace std;

int main()
{
    int lenght, width;
    float perimeter, area;
    cout<<"Enter the length :";
    cin>>lenght;
    cout<<"\nEnter the width :";
    cin>>width;
    area = (lenght * width);
    perimeter = (lenght + width) * 2;
    cout<<"The area of the rectangle is :"<<area;
    cout<<"\nThe perimeter of the rectangle is :"<<perimeter;
    return 0;
}
